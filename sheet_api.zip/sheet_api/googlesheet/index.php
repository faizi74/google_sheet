<?php
require __DIR__ . '/vendor/autoload.php';
$client = new \Google_Client();
$client->setApplicationName('Google Sheets and PHP');
$client->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
$client->setAccessType('offline');
$client->setAuthConfig('credentials.json');
$service=new Google_Service_Sheets($client);
$spreadsheetId="1fWbYl3YYv-78dgrGkrAhppoFoKtJ_AMMqF90REV6gTg";
$range="Sheet1";
$response=$service->spreadsheets_values->get($spreadsheetId,$range);
$values=$response->getValues();



if (empty($values)) 
{
    print "No Data Found...!!!";
}
else
{
    //print_r($values);
}
$rows=sizeof($values);
$columns = count(current($values));
?>

<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script>
            $(document).ready(function () {
$('#dtHorizontalExample').DataTable({
"scrollX": true
});
$('.dataTables_length').addClass('bs-select');
});
        </script>
</head>
<body>
<form method="POST" action="gen_excel.php">
    <input type="hidden" name="data" value="<?php echo htmlentities(serialize($values));?>">
	<button type="submit" class="btn btn-primary" name="generate">Generate Excel File</button>
</form>
<div class="container">       
  <table class="table table-hover">
    <thead>
        <tr>
        <?php
        if($values)
        {
            for($i=0;$i<$columns;$i++)
            {
                ?>
                <th><?php echo $values[0][$i];  ?></th>
                
                <?php
            }
        }
        ?>
      </tr>
    </thead>
    <tbody>
        <?php
        if($values)
        {
            for($i=1;$i<$rows;$i++)  
            {
                ?>
                <tr>
                <?php
               for($j=0;$j<$columns;$j++) 
               {
                  ?>
                  <td><?php echo $values[$i][$j];  ?></td>
                  <?php
               }
               ?>
               </tr>
          <?php  }
        }
        ?>
    </tbody>
  </table>
</div>

</body>
</html>

