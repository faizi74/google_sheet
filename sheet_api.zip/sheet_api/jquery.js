$(function() {
    $('path').click(function() {
        var id=this.id;
        if(id=="akkar1")
        {
            window.open("index.php?id=1");
        }
        else if(id=="bekaa1")
            {
                window.open("index.php?id=2"); 
            }
        
        else if(id=="beirut1")
            {
                 window.open("index.php?id=3");
            }
        else if(id=="north1")
            {
                 window.open("index.php?id=4");
            }
        else if(id=="nabatieh1")
            {
                 window.open("index.php?id=5");
            }
        else if(id=="mount_lebanon1")
            {
                 window.open("index.php?id=6");
            }
        else if(id=="south1")
            {
                 window.open("index.php?id=7");
            }
        else if(id=="baalbek_hermel1")
            {
                 window.open("index.php?id=8");
            }
        
    });
    
});
    