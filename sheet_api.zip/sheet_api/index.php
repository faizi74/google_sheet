<?php
require __DIR__ . '/vendor/autoload.php';
$client = new \Google_Client();
$client->setApplicationName('Google Sheets and PHP');
$client->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
$client->setAccessType('offline');
$client->setAuthConfig('credentials.json');
$service=new Google_Service_Sheets($client);
$spreadsheetId="1SfUjN3OhmD9OOFQNmwN9xi2kVhSMTOyEYEQCg_wg03w";
$range="Sheet1";
$response=$service->spreadsheets_values->get($spreadsheetId,$range);
$values=$response->getValues();



$rows=sizeof($values);
$columns = count(current($values));

?>

<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="https://code.highcharts.com/maps/highmaps.js"></script>
<script src="https://code.highcharts.com/maps/modules/exporting.js"></script>
<script src="https://code.highcharts.com/mapdata/countries/lb/lb-all.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
table
{
    background-color:aliceblue;
    -webkit-box-shadow: 0 0 10px grey;
        box-shadow: 0 0 10px grey;
}
ul
{
    -webkit-box-shadow: 0 0 10px grey;
        box-shadow: 0 0 10px grey;
    max-height:400px;
    overflow:hidden; 
    overflow-y:scroll;
}
.btn-primary,.btn-primary:hover
{
    background-color:whitesmoke;
    border-color:whitesmoke;
}
p,a
{
    color:black !important;
    font-weight:bold;
}
.highcharts-title
{
    display:none;
}
.highcharts-credits tspan
{
    display:none;
}
.highcharts-legend
{
    displaY:none;
}
    .highcharts-anchor,.highcharts-button-symbol
    {
        display: none;
    }
    @font-face {
        font-family: 'Proximabold';
        src: url('fonts/Proxima Nova Alt Bold.otf');
    }
    @font-face {
        font-family: 'Proximalight';
        src: url('fonts/Proxima Nova Alt Light.otf');
    }
    h2,h3,h6{
        font-family: Proximabold;
        color: black;
    }
    p,li{
        font-family: Proximalight;
        color:grey;
    }
    html
    {
      font-family: Proximalight;
      -ms-text-size-adjust: 100%;
      -webkit-text-size-adjust: 100%;
    }
    #tbl
    {
        font-family: Proximalight;
        display: block;
    }
    td
    {
        font-size:15px;
    }
    #container
    {
        padding-top:40px;
    }
    .list-group-item {
    border-bottom: none;
    border-right: none;
    border-left: none;
}
    #akk,
#baalbek,
#mount,
#nabatieh,
#north,
#south,
#south_mount,
#north_mount,
    #show_assets_ablah,#show_assets_alain,#show_assets_bouday
    {
        display: none;
    }
   
        </style>
        <script>
            
            $(function() {
            $.urlParam = function (name) {
                var results = new RegExp('[\?&]' + name + '=([^&#]*)')
                                  .exec(window.location.search);

                return (results !== null) ? results[1] || 0 : false;
            }
            if($.urlParam('id')==1)
                {
                    $("#akk").show();
                }
            else if($.urlParam('id')==2)
                {
                    $("#baalbek").show();
                }
                else if($.urlParam('id')==3)
                {
                    $("#baalbek").show();
                }
                
                else if($.urlParam('id')==4)
                {
                    $("#north").show();
                }
                
                else if($.urlParam('id')==5)
                {
                    $("#nabatieh").show();
                }
                
                else if($.urlParam('id')==6)
                {
                    $("#mount").show();
                }
                
                else if($.urlParam('id')==7)
                {
                    $("#south").show();
                }
                
                else if($.urlParam('id')==8)
                {
                    $("#baalbek").show();
                }
               
            });
            
            
            
            
            $(function() {
    $('a').click(function() {
        var id=this.id;
        if(id=="city_ablah")
            {
                $("#show_assets_ablah").show();
                
            }
        else if(id=="city_alain")
            {
                $("#show_assets_alain").show();
            }
        else if(id=="city_bouday")
            {
                $("#show_assets_bouday").show();
            }
    });
            });
        
            
        
        </script>
         
</head>
    
    <body>
        <div class="container">
        <div class="row">
        
            <div class="col-sm-5 col-12">
            
               <object data="map.svg" type="image/svg+xml">
                  <img  src="map.svg" />
                </object>
                
            </div>
            
            <div class="col-sm-3 col-12">
                
                
                <div id="akk" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">Akkar</h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                     <p> Aandqet</p>
                      
                       <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Hadath Baalbak")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aandqet&&region=1" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aandqet&&region=1" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                  <li style="text-align:center" class="list-group-item">
                      <p> Bireh</p>
                    
                       <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Hadath Baalbak")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Bireh&&region=1" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Bireh&&region=1" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    <li style="text-align:center" class="list-group-item">
                      <p> Mhammara</p>
                      
                      
                       <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mhammara")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Mhammara&&region=1" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Mhammara&&region=1" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    <li style="text-align:center" class="list-group-item">
                      <p> Qbaiyat</p>
                    
                      
                       <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Qbaiyat")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qbaiyat&&region=1" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qbaiyat&&region=1" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    <li style="text-align:center" class="list-group-item">
                     <p>Hrar</p>
                      
                      
                       <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Hrar")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Hrar&&region=1>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Hrar&&region=1" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                   
                    
                </ul>
                    
                    </div>
                   
                </div>
                
                
                <div id="baalbek" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">Baalbek</h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                      <p>Al-Ain</p>
                      
                       <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Al Ain")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Al Ain&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Al Ain&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                     
                    </li>
                  
                    
                     <li style="text-align:center" class="list-group-item">
                     <p> Ablah </p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ablah")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Ablah&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ablah&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      
                      
                      
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Chaat</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Chaat")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Chaat&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Chaat&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      
                      
                    </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Hadath Baalbak</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Hadath Baalbak")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Hadath Baalbak&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Hadath Baalbak&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Laboueh</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Laboueh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Laboueh&&region=2>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Laboueh&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Qsarnaba</p>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Qsarnaba")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qsarnaba&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qsarnaba&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Ras Baalbak Es Sahel</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ras Baalbak Es Sahel")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Ras Baalbak Es Sahel&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ras Baalbak Es Sahel&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Serraine Et Tahta</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Serraine Et Tahta")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Serraine Et Tahta&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Serraine Et Tahta&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Chmistar</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Chmistar")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Chmistar&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Chmistar&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Taraya</p>
                          
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Taraya")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Taraya&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Taraya&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Temnine EL Faouqa</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Temnine EL Faouqa")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Temnine EL Faouqa&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Temnine EL Faouqa&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      
                      </li>
                    
                     <li style="text-align:center" class="list-group-item">
                    <p>Bouday</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Bouday")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Bouday&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Bouday&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Temnine ElTahta</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Temnine ElTahta")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Temnine ElTahta&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Temnine ElTahta&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Younine</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Younine")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Younine&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Younine&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Douris</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Douris")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Douris&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Douris&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                    
                    
                    
                    
                   
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> ElManara</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="ElManara")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=ElManara&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=ElManara&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Lala</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Lala")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Lala&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Lala&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Mashghara</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mashghara")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Masghara&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Masghara&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Rashaya </p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Rashaya")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Rashaya&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Rashaya&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Sohmor</p>
                      
                      
                     <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Sohmor")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Sohmor&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Sohmor&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                     </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Qab Elias</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Qab Elias")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qab Elias&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qab Elias&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>SOUAIRI </p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="SOUAIRI")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=SOUAIRI&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=SOUAIRI&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Chtoura</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Chtoura")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Chtoura&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Chtoura&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Rafid </p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Rafid")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Rafid&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Rafid&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Mansoura</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mansoura")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Mansoura&&region=2" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Mansoura&&region=2" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                   
                 
                   
                    
                </ul>
                    
                    </div>
                   
                </div>
                
                
                <div id="mount" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">Middle Mount Lebanon</h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                     <p> Borj El Brajneh</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Borj El Brajneh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Borj El Brajneh&&region=4" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Borj El Brajneh&&region=4" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                  <li style="text-align:center" class="list-group-item">
                     <p> Ghbayreh</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ghbayreh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Ghbayreh&&region=4" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ghbayreh&&region=4" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p> Ech Choueifat</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ech Choueifat")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Ech Choueifat&&region=4" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ech Choueifat&&region=4" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Mreijeh</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mreijeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Mreijeh&&region=4" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Mreijeh&&region=4" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p> Harit Hreik</p>
                   
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Harit Hreik")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Harit Hreik&&region=4" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Harit Hreik&&region=4" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                   
                   
                 
                   
                    
                </ul>
                    
                    </div>
                    
                </div>
                
                
                
                <div id="nabatieh" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">Nabatieh</h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                      <p>Ainata</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ainata")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Ainata&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ainata&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                  <li style="text-align:center" class="list-group-item">
                      <p>Aaytaroun</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aaytaroun")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aaytaroun&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aaytaroun&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p> Ansar</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ansar")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Ansar&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ansar&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Aarab Salim</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aarab Salim")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aarab Salim&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aarab Salim&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Bent Jbeil</p>
                    
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Bent Jbeil")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Bent Jbeil&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Bent Jbeil&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Deir Ez Zahrani</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Deir Ez Zahrani")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Deir Ez Zahrani&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Deir Ez Zahrani&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Douair</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Douair")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Douair&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Douair&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Nabatiyeh Et Tahta</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Nabatiyeh Et Tahta")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Nabatiyeh Et Tahta&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Nabatiyeh Et Tahta&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p>Qsaibeh</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Qsaibeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qsaibeh&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qsaibeh&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                  <p>Habbouch </p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Habbouch")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Habbouch&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Habbouch&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Hariss</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Hariss")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Hariss&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Hariss&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Hasbaiya</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Hasbaiya")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Hasbaiya&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Hasbaiya&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Jibchit</p>
                     
                      
                     <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Jibchit")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Jibchit&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Jibchit&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                     </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Kfar Kila</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Kfar Kila")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Kfar Kila&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Kfar Kila&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                    
                    
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Kfar sir</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Kfar sir")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Kfar Sir&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Kfar Sir&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Meiss El Jabal</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Meiss El Jabal")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Meiss El Jabal&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Meiss El Jabal&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Majdel Selem</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Majdel Selem")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Majdel Selem&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Majdel Selem&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Rmeish</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Rmeish")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Rmeish&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Rmeish&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Shaqra </p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Shaqra")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Shaqra&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Shaqra&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Tebnine</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Tebnine")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Tebnine&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Tebnine&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                   <p> Zebdeen</p>
                       
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Zebdeen")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Zebdeen&&region=5" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Zebdeen&&region=5" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                  
                   
                    
                </ul>
                    
                    </div>
                   
                </div>
                
                
        
                <div id="north" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">North</h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                      <p>Amioun</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Amioun")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Amioun&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Amioun&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                       </li>
                  <li style="text-align:center" class="list-group-item">
                      <p>Anfeh</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Anfeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Anfeh&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Anfeh&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p> Chikka</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Chikka")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Chikka&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Chikka&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p>Izal</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Izal")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Izal&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Izal&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p> Deir Aamar</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Deir Aamar")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Deir Aamar&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Deir Aamar&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Kousba</>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Kousba")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Kousba&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Kousba&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p>Mejdlaiya</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mejdlaiya")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Mejdlaiya&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Mejdlaiya&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                    <p>  Mina 2</p>
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mina 2")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Mina 2&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Mina 2&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p>Mina 3</p>
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mina 3")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Mina 3&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Mina 3&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                  <p>Zouq Bhannine </p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Zouq Bhannine")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Zouq Bhannine&&region=6" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Zouq Bhannine&&region=6" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                   
                   
                    
                </ul>
                    
                    </div>
                    
                </div>
                
                
                <div id="south" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">South</h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                   <p>   Aabasiyeh Sour</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aabasiyeh Sour")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aabasiyeh Sour&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aabasiyeh Sour&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                  <li style="text-align:center" class="list-group-item">
                     <p>  Aabra</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aabra")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aabra&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aabra&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p> Ain Baal</p>
                     
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Ain Baal")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Ain Baal&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p>  Aadloun</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aadloun")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aadloun&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aadloun&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                       </li>
                    <li style="text-align:center" class="list-group-item">
                      <p> Aanqoun</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aanqoun")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aanqoun&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aanqoun&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    <li style="text-align:center" class="list-group-item">
                     <p>  Insariyeh</p>
                    
                     
                     <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Insariyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Insariyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Insariyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?> 
                     </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p> Aaytit</p>
                  
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Aaytit")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Aaytit&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Aaytit&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p> Barich</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Barich")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Barich&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Barich&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Bazouriyeh</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Bazouriyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Bazouriyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Bazouriyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                 <p>  Bedias</p>

                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Bedias")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Bedias&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Bedias&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                   
                   
                    
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p>  Chehabiyeh</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Chehabiyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Chehabiyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Chehabiyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                     <p>  Deir Qanoun - El Ain</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Deir Qanoun - El Ain")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Deir Qanoun - El Ain&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Deir Qanoun - El Ain&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      <p> Qalileh</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Qalileh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qalileh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qalileh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    
                    <li style="text-align:center" class="list-group-item">
                     <p>  Qrayeh</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Qrayeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qrayeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qrayeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                       </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p>  Saksakiyeh</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Saksakiyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Saksakiyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Saksakiyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      <p> Haret Saida</p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Haret Saida")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Haret Saida&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Haret Saida&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                     <p> Hlaliyeh</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Hlaliyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Hlaliyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Hlaliyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                <p>   Jezzine</p>
                  
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Jezzine")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Jezzine&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Jezzine&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    
                    
                     <li style="text-align:center" class="list-group-item">
                    <p>   Jouaiya</p>
                  
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Jouaiya")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Jouaiya&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Jouaiya&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                    <p>  Maarakeh</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Maarakeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Maarakeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Maarakeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                 <p>  Maghdoucheh</p>
                   
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Maghdoucheh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Maghdoucheh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Maghdoucheh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                     <li style="text-align:center" class="list-group-item">
                     <p>  Qana</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Qana")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Qana&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Qana&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                    <p>  Roum</p>
                     
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Roum")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Roum&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Roum&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                <p>   Srifa</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Srifa")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Srifa&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Srifa&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                     <li style="text-align:center" class="list-group-item">
                    <p>   Tayr Debba</p>
                   
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Tayr Debba")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Tayr Debba&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Tayr Debba&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                   <p>   Tayr Falsay</p>
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Tayr Falsay")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Tayr Falsay&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Tayr Falsay&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                  <p> Sour</p> 
                
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Sour")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Sour&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Sour&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                     <li style="text-align:center" class="list-group-item">
                    <p>    Miyeh Ou Miyeh </p>
                    
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==" Miyeh Ou Miyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Miyeh Ou Miyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Miyeh Ou Miyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                    <p>  Darb es Sim</p>
                      
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Darb es Sim")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Darb es Sim&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Darb es Sim&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                  <p> Zrariyeh</p>
                     
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Zrariyeh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="index.php?city=Zrariyeh&&region=7" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="index.php?city=Zrariyeh&&region=7" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    
                    
                    
                    
                </ul>
                    
                    </div>
                    
                </div>
                
                
                <div id="south_mount" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">South Mount Lebanon </h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                      Aaley
                      <br>
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Aaley")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                  <li style="text-align:center" class="list-group-item">
                      Baaqline
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Baaqline")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?>
                      </li>
                    <li style="text-align:center" class="list-group-item">
                      Bayssour
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Bayssour")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    <li style="text-align:center" class="list-group-item">
                       Jdaideh (Chouf) 
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Jdaideh (Chouf)")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    <li style="text-align:center" class="list-group-item">
                    Kfar Nabrakh
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Kfar Nabrakh")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    
                    <li style="text-align:center" class="list-group-item">
                      Mazboud
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Mazboud")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      Sibline
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Sibline")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    
                    
                    <li style="text-align:center" class="list-group-item">
                      Damour
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Damour")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                    
                    
                  
                    
                </ul>
                    
                    </div>
                    
                </div>
                
                <div id="north_mount" class="row">
                
                    <div class="col-sm-12 col-12">
                    <h3 style="text-align:center;">North Mount Lebanon </h3>
                <ul class="list-group">
                  <li style="text-align:center" class="list-group-item">
                      Jbeil
                      <br>
                      
                      <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]=="Jbeil")
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
             ?>
             
                        <a href="<?php  echo $values[$starting_index_row][$cityindex+3];  ?>" class="btn btn-primary btn-sm">
                            <i class="glyphicon glyphicon-download-alt"></i>
                            Download All
                        </a>
            <?php
            
            }
            else
            {
                ?>
                        <a href="#" class="btn btn-primary btn-sm">
                          <i class="glyphicon glyphicon-download-alt"></i>
                          Download All
                        </a>
                
                
                <?php
            }
            
        }   
        
          
                
                ?></li>
                
                    
                </ul>
                    
                    </div>
                    
                    
                </div>
        
        </div>
        
        
            <div class="col-sm-4 col-12">
                
                <?php
                if(isset($_GET['city']))
           {
               $city=$_GET['city'];
               $region=$_GET['region'];
               ?>
                <h3 style="text-align:center;"><?php echo $city; ?></h3>
                
                <table class="table table-hover">
                
                    
                    
                <script>
                    
                    $(function() {
                    var region="<?php  echo $region; ?>";
                    
            if(region==1)
                {
                    $("#akk").show();
                }
            else if(region==2)
                {
                    $("#baalbek").show();
                }
                else if(region==3)
                {
                    $("#baalbek").show();
                }
                
                else if(region==4)
                {
                    $("#north").show();
                }
                
                else if(region==5)
                {
                    $("#nabatieh").show();
                }
                
                else if(region==6)
                {
                    $("#mount").show();
                }
                
                else if(region==7)
                {
                    $("#south").show();
                }
                
                else if(region==8)
                {
                    $("#baalbek").show();
                }
               
            });
                    
                    
                </script>
                
                <?php
           
        
        $cityindex="";
        $starting_index_row="";
        $ending_index_row="";
        if($values)
        {
           //fetch Index of city coloumn
        
            for($i=0;$i<$rows;$i++)  
            {
                
               for($j=0;$j<$columns;$j++) 
               {
                   
                   if($values[$i][$j]=="City")
                   {
                
                       $cityindex=$j;
                   }
               }
               
            }
            
            // fetch names against cities and get starting index
            for($i=0;$i<$rows;$i++)  
            {
                
                $specific_city=$city;
                
                if($values[$i][$cityindex]==$specific_city)
                {
                    $starting_index_row=$i;
                }
               
            }
            
            
             // fetch ending  Index of city
            
            if($starting_index_row!="")
            {
               for($i=$starting_index_row+1;$values[$i][$cityindex]=="";$i++)  
                {
                   $ending_index_row=$i;
                } 
            
            
            ?>
            <a href="<?php  echo $values[$starting_index_row][$cityindex+3]  ?>">
                <img src='folder.JPG'> <i style="margin-left:20px;" class='glyphicon glyphicon-download-alt'></i></a>
            <?php
                echo "<tbody>";
            for($i=$starting_index_row+1;$i<=$ending_index_row;$i++)
            {
                
                ?>
                
                        <tr>
                            
                            <td>
                            <?php  
                             if($values[$i][$cityindex+1]=="XLSX")
                             {
                                 ?>
                                 <img src="excel.JPG">
                                 <?php
                             }
                             else if($values[$i][$cityindex+1]=="DOC")
                             {
                                 ?>
                                 <img src="word.JPG">
                                 <?php
                             }
                             else if($values[$i][$cityindex+1]=="PDF")
                             {
                                 ?>
                                 <img src="pdf.JPG">
                                 <?php
                             }
                             ?></td>
                            <td style="font-weight:bold;"><?php  echo $values[$i][$cityindex+2];  ?></td>
                            
                             <td><?php  
                             if($values[$i][$cityindex+5])
                             {
                                 echo $values[$i][$cityindex+5];
                             }
                             ?></td>
                            <td><a href="<?php  echo $values[$i][$cityindex+3]  ?>" class="btn btn-primary btn-sm" ><i class="glyphicon glyphicon-download-alt"></i> Download</a></td>
                           
    
                        </tr>
                <?php
               
            }
            echo "</tbody>";
            }
            else
            {
                ?>
                
                <tbody>
                    
                    <tr>
                        <th>No file Attached</th>
                        </tr>
                    
                </tbody>
                
                <?php
            }
            
        }   
        
               
           }
                
                ?>
                
               
                
                
              </table>  
                        
                    
                    
                          
                              
                            
            </div>
                    
            </div>
            
        </div>

    </body>
</html>